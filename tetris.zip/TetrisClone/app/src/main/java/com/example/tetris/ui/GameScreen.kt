package com.example.tetris.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tetris.data.HighScores
import com.example.tetris.game.GameEvent
import com.example.tetris.game.PieceType
import com.example.tetris.game.SHAPES
import com.example.tetris.game.TetrisEngine
import com.example.tetris.sound.Sfx
import com.example.tetris.sound.SoundManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.min

class GameController(private val sound: SoundManager?) {
    val engine = TetrisEngine()
    var tick by mutableStateOf(0L)
        private set
    var onGameOver by mutableStateOf(false)
        private set

    private fun refresh() { tick++ }

    private fun consumeEvents() {
        engine.pendingEvent?.let { ev ->
            when (ev) {
                GameEvent.LOCK -> sound?.play(Sfx.LOCK)
                GameEvent.CLEAR -> sound?.play(Sfx.CLEAR)
                GameEvent.LEVEL_UP -> sound?.play(Sfx.LEVEL_UP)
                GameEvent.GAME_OVER -> {
                    sound?.play(Sfx.GAME_OVER)
                    onGameOver = true
                }
            }
            engine.pendingEvent = null
        }
    }

    fun left() {
        if (engine.move(-1)) { sound?.play(Sfx.MOVE); refresh() }
    }

    fun right() {
        if (engine.move(1)) { sound?.play(Sfx.MOVE); refresh() }
    }

    fun rotate() {
        if (engine.gameOver || engine.paused) return
        engine.rotate()
        sound?.play(Sfx.ROTATE)
        refresh()
    }

    fun down() {
        if (engine.softDrop()) refresh()
    }

    fun hardDrop() {
        if (engine.gameOver || engine.paused) return
        engine.hardDrop()
        sound?.play(Sfx.DROP)
        consumeEvents()
        refresh()
    }

    fun togglePause() {
        if (engine.gameOver) return
        engine.paused = !engine.paused
        if (engine.paused) sound?.pauseMusic() else sound?.startMusic()
        refresh()
    }

    fun frame() {
        engine.tick()
        consumeEvents()
        refresh()
    }

    fun restart() {
        engine.reset()
        onGameOver = false
        refresh()
    }
}

fun colorOfIndex(i: Int): Color =
    Color(PieceType.values().first { it.index == i }.color)

@Composable
fun GameScreen(sound: SoundManager, onExit: () -> Unit, onGoScores: () -> Unit) {
    val context = LocalContext.current
    val controller = remember { GameController(sound) }
    val engine = controller.engine
    val tick = controller.tick
    var showGameOver by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        sound.startMusic()
        while (isActive) {
            delay(engine.dropIntervalMs())
            controller.frame()
        }
    }
    DisposableEffect(Unit) {
        onDispose { sound.pauseMusic() }
    }
    BackHandler { controller.togglePause() }

    LaunchedEffect(controller.onGameOver) {
        if (controller.onGameOver) {
            sound.pauseMusic()
            showGameOver = true
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F1A))
            .padding(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                InfoText("Puntos", engine.score)
                InfoText("Nivel", engine.level)
                InfoText("Líneas", engine.lines)
            }
            NextPreview(engine.nextType)
            Spacer(Modifier.width(8.dp))
            Column {
                Button(onClick = { controller.togglePause() }) {
                    Text(if (engine.paused) "▶" else "⏸")
                }
                Spacer(Modifier.height(4.dp))
                Button(onClick = onExit) { Text("✕") }
            }
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.weight(1f).fillMaxWidth()) {
            BoardCanvas(engine, tick)
            if (engine.paused && !engine.gameOver) {
                Box(
                    Modifier.fillMaxSize().background(Color(0xAA000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "PAUSA",
                        color = Color.White,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Controls(controller)
    }

    if (showGameOver) {
        GameOverDialog(
            score = engine.score,
            onSave = { name ->
                HighScores.add(context, name, engine.score)
                onGoScores()
            },
            onRetry = {
                controller.restart()
                showGameOver = false
                sound.startMusic()
            },
            onExit = onExit
        )
    }
}

@Composable
private fun InfoText(label: String, value: Int) {
    Text(
        "$label: $value",
        color = Color(0xFFE2E8F0),
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun NextPreview(type: PieceType) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Siguiente", color = Color(0xFF94A3B8), fontSize = 12.sp)
        Canvas(Modifier.size(64.dp)) {
            val cells = SHAPES.getValue(type)
            val cell = min(size.width, size.height) / 4f
            val ox = (size.width - 4 * cell) / 2f
            val oy = (size.height - 4 * cell) / 2f
            for ((cx, cy) in cells) {
                drawRect(
                    color = Color(type.color),
                    topLeft = Offset(ox + cx * cell + 1f, oy + cy * cell + 1f),
                    size = Size(cell - 2f, cell - 2f)
                )
            }
        }
    }
}

@Composable
private fun BoardCanvas(engine: TetrisEngine, tick: Long) {
    Canvas(Modifier.fillMaxSize()) {
        val cell = min(size.width / engine.cols, size.height / engine.rows)
        val ox = (size.width - cell * engine.cols) / 2f
        val oy = (size.height - cell * engine.rows) / 2f

        fun cellRect(nx: Int, ny: Int, color: Color, alpha: Float = 1f) {
            drawRect(
                color = color.copy(alpha = alpha),
                topLeft = Offset(ox + nx * cell + 1f, oy + ny * cell + 1f),
                size = Size(cell - 2f, cell - 2f)
            )
        }

        drawRect(
            Color(0xFF111827),
            Offset(ox, oy),
            Size(cell * engine.cols, cell * engine.rows)
        )

        if (!engine.gameOver) {
            val gy = engine.ghostY()
            for ((cx, cy) in engine.currentCells) {
                val ny = gy + cy
                if (ny >= 0) cellRect(engine.currentX + cx, ny, Color(engine.currentType.color), 0.22f)
            }
        }

        for (r in 0 until engine.rows) {
            for (c in 0 until engine.cols) {
                val v = engine.grid[r][c]
                if (v != 0) cellRect(c, r, colorOfIndex(v))
            }
        }

        if (!engine.gameOver) {
            for ((cx, cy) in engine.currentCells) {
                val ny = engine.currentY + cy
                if (ny >= 0) cellRect(engine.currentX + cx, ny, Color(engine.currentType.color))
            }
        }

        drawRect(
            Color(0xFF334155),
            Offset(ox, oy),
            Size(cell * engine.cols, cell * engine.rows),
            style = Stroke(width = 2f)
        )
    }
}

@Composable
private fun Controls(controller: GameController) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        CtrlButton("◀") { controller.left() }
        CtrlButton("⟳") { controller.rotate() }
        CtrlButton("▼") { controller.down() }
        CtrlButton("▶") { controller.right() }
        CtrlButton("⏬") { controller.hardDrop() }
    }
}

@Composable
private fun CtrlButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.size(60.dp),
        shape = RoundedCornerShape(10.dp),
        contentPadding = PaddingValues(0.dp)
    ) {
        Text(text, fontSize = 20.sp)
    }
}

@Composable
private fun GameOverDialog(
    score: Int,
    onSave: (String) -> Unit,
    onRetry: () -> Unit,
    onExit: () -> Unit
) {
    val context = LocalContext.current
    val isRecord = HighScores.isHighScore(context, score)
    var name by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = {},
        title = { Text("Fin de la partida") },
        text = {
            Column {
                Text("Puntuación: $score", fontWeight = FontWeight.Bold)
                if (isRecord) {
                    Spacer(Modifier.height(8.dp))
                    Text("¡Nuevo récord! Escribe tu nombre:", color = Color(0xFFFFD600))
                    Spacer(Modifier.height(4.dp))
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Tu nombre") },
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name.ifBlank { "Jugador" }) }) { Text("Guardar") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onRetry) { Text("Reintentar") }
                TextButton(onClick = onExit) { Text("Salir") }
            }
        }
    )
}
