package com.example.tetris.sound

import android.content.Context
import android.media.MediaPlayer
import android.media.SoundPool
import com.example.tetris.R

enum class Sfx { MOVE, ROTATE, DROP, LOCK, CLEAR, LEVEL_UP, GAME_OVER }

class SoundManager(context: Context) {
    private val soundPool = SoundPool.Builder().setMaxStreams(4).build()
    private val ids = mutableMapOf<Sfx, Int>()
    private var music: MediaPlayer? = null

    var sfxOn = true
    var musicOn = true

    init {
        val res = mapOf(
            Sfx.MOVE to R.raw.snd_move,
            Sfx.ROTATE to R.raw.snd_rotate,
            Sfx.DROP to R.raw.snd_drop,
            Sfx.LOCK to R.raw.snd_lock,
            Sfx.CLEAR to R.raw.snd_clear,
            Sfx.LEVEL_UP to R.raw.snd_levelup,
            Sfx.GAME_OVER to R.raw.snd_gameover,
        )
        for ((sfx, id) in res) {
            runCatching { ids[sfx] = soundPool.load(context, id, 1) }
        }
        runCatching {
            music = MediaPlayer.create(context, R.raw.music).apply {
                isLooping = true
                setVolume(0.45f, 0.45f)
            }
        }
    }

    fun play(sfx: Sfx) {
        if (!sfxOn) return
        ids[sfx]?.let { runCatching { soundPool.play(it, 1f, 1f, 1, 0, 1f) } }
    }

    fun startMusic() {
        if (musicOn) runCatching { music?.start() }
    }

    fun pauseMusic() {
        runCatching { music?.pause() }
    }

    fun release() {
        runCatching { soundPool.release() }
        runCatching { music?.release() }
        music = null
    }
}
