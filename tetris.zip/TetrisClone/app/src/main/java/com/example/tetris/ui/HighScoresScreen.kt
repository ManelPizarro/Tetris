package com.example.tetris.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tetris.data.HighScores
import com.example.tetris.data.ScoreEntry

@Composable
fun HighScoresScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scores = remember { HighScores.load(context) }
    Column(Modifier.fillMaxSize().background(Color(0xFF0B0F1A)).padding(16.dp)) {
        Spacer(Modifier.height(16.dp))
        Text(
            "🏆  Puntuaciones máximas",
            color = Color(0xFFE2E8F0),
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(16.dp))
        if (scores.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("Aún no hay puntuaciones. ¡Juega una partida!", color = Color(0xFF94A3B8))
            }
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(scores.size) { i ->
                    ScoreRow(i + 1, scores[i])
                }
            }
        }
        Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
            Text("Volver al menú")
        }
    }
}

@Composable
private fun ScoreRow(rank: Int, entry: ScoreEntry) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "#$rank",
            color = Color(0xFF00E5FF),
            fontWeight = FontWeight.Bold,
            modifier = Modifier.width(48.dp)
        )
        Text(entry.name, color = Color(0xFFE2E8F0), modifier = Modifier.weight(1f))
        Text("${entry.score}", color = Color(0xFFFFD600), fontWeight = FontWeight.Bold)
    }
}
