package com.example.tetris.game

enum class GameEvent { LOCK, CLEAR, LEVEL_UP, GAME_OVER }

class TetrisEngine {
    val cols = 10
    val rows = 20

    var grid = Array(rows) { IntArray(cols) }
        private set
    var score = 0
        private set
    var lines = 0
        private set
    var level = 1
        private set
    var gameOver = false
        private set
    var paused = false
    var pendingEvent: GameEvent? = null

    var currentType: PieceType = PieceType.I
        private set
    var currentCells: List<Pair<Int, Int>> = emptyList()
        private set
    var currentX = 0
        private set
    var currentY = 0
        private set
    var nextType: PieceType = PieceType.I
        private set

    private var bag = Bag()
    private var box = 4

    init { reset() }

    fun reset() {
        grid = Array(rows) { IntArray(cols) }
        score = 0
        lines = 0
        level = 1
        gameOver = false
        paused = false
        pendingEvent = null
        bag = Bag()
        currentType = bag.next()
        nextType = bag.next()
        placeCurrent()
    }

    private fun placeCurrent() {
        box = boxSize(currentType)
        currentCells = SHAPES.getValue(currentType)
        currentX = 3
        currentY = 0
        if (collides(currentCells, currentX, currentY)) {
            gameOver = true
            pendingEvent = GameEvent.GAME_OVER
        }
    }

    fun dropIntervalMs(): Long = (800 - (level - 1) * 65).coerceAtLeast(70).toLong()

    private fun collides(cells: List<Pair<Int, Int>>, x: Int, y: Int): Boolean {
        for ((cx, cy) in cells) {
            val nx = x + cx
            val ny = y + cy
            if (nx < 0 || nx >= cols || ny >= rows) return true
            if (ny >= 0 && grid[ny][nx] != 0) return true
        }
        return false
    }

    fun move(dx: Int): Boolean {
        if (gameOver || paused) return false
        if (!collides(currentCells, currentX + dx, currentY)) {
            currentX += dx
            return true
        }
        return false
    }

    fun rotate() {
        if (gameOver || paused || currentType == PieceType.O) return
        val rotated = currentCells.map { (x, y) -> y to (box - 1 - x) }
        for (dx in listOf(0, -1, 1, -2, 2)) {
            for (dy in listOf(0, -1)) {
                if (!collides(rotated, currentX + dx, currentY + dy)) {
                    currentCells = rotated
                    currentX += dx
                    currentY += dy
                    return
                }
            }
        }
    }

    fun softDrop(): Boolean {
        if (gameOver || paused) return false
        if (!collides(currentCells, currentX, currentY + 1)) {
            currentY++
            score++
            return true
        }
        lock()
        return false
    }

    fun tick() {
        if (gameOver || paused) return
        if (!collides(currentCells, currentX, currentY + 1)) {
            currentY++
        } else {
            lock()
        }
    }

    fun hardDrop() {
        if (gameOver || paused) return
        var d = 0
        while (!collides(currentCells, currentX, currentY + 1)) {
            currentY++
            d++
        }
        score += d * 2
        lock()
    }

    fun ghostY(): Int {
        var y = currentY
        while (!collides(currentCells, currentX, y + 1)) y++
        return y
    }

    private fun lock() {
        for ((cx, cy) in currentCells) {
            val ny = currentY + cy
            if (ny < 0) {
                gameOver = true
                pendingEvent = GameEvent.GAME_OVER
                return
            }
            grid[ny][currentX + cx] = currentType.index
        }
        pendingEvent = GameEvent.LOCK
        clearLines()
        val oldLevel = level
        level = lines / 10 + 1
        if (level > oldLevel) pendingEvent = GameEvent.LEVEL_UP
        currentType = nextType
        nextType = bag.next()
        placeCurrent()
    }

    private fun clearLines() {
        var cleared = 0
        var r = rows - 1
        while (r >= 0) {
            if (grid[r].all { it != 0 }) {
                for (rr in r downTo 1) grid[rr] = grid[rr - 1].copyOf()
                grid[0] = IntArray(cols)
                cleared++
            } else {
                r--
            }
        }
        if (cleared > 0) {
            lines += cleared
            score += when (cleared) {
                1 -> 40
                2 -> 100
                3 -> 300
                else -> 1200
            } * level
            pendingEvent = GameEvent.CLEAR
        }
    }
}
