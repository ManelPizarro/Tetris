package com.example.tetris

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.tetris.sound.SoundManager
import com.example.tetris.ui.GameScreen
import com.example.tetris.ui.HighScoresScreen
import com.example.tetris.ui.MenuScreen

private val DarkColors = darkColorScheme(
    primary = Color(0xFF00E5FF),
    onPrimary = Color(0xFF00363D),
    background = Color(0xFF0B0F1A),
    surface = Color(0xFF151B2E),
    surfaceVariant = Color(0xFF1E2740),
)

class MainActivity : ComponentActivity() {

    private lateinit var sound: SoundManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sound = SoundManager(this)
        setContent {
            MaterialTheme(colorScheme = DarkColors) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TetrisApp(sound)
                }
            }
        }
    }

    override fun onPause() {
        sound.pauseMusic()
        super.onPause()
    }

    override fun onDestroy() {
        sound.release()
        super.onDestroy()
    }
}

@Composable
fun TetrisApp(sound: SoundManager) {
    var screen by rememberSaveable { mutableStateOf("menu") }
    when (screen) {
        "menu" -> MenuScreen(
            onPlay = { screen = "game" },
            onScores = { screen = "scores" }
        )
        "game" -> GameScreen(
            sound = sound,
            onExit = { screen = "menu" },
            onGoScores = { screen = "scores" }
        )
        "scores" -> HighScoresScreen(onBack = { screen = "menu" })
    }
}
