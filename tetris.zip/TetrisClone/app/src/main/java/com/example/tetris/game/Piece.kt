package com.example.tetris.game

enum class PieceType(val color: Long, val index: Int) {
    I(0xFF00E5FF, 1),
    O(0xFFFFD600, 2),
    T(0xFFAB47BC, 3),
    S(0xFF66BB6A, 4),
    Z(0xFFEF5350, 5),
    J(0xFF42A5F5, 6),
    L(0xFFFF9100, 7),
}

val SHAPES: Map<PieceType, List<Pair<Int, Int>>> = mapOf(
    PieceType.I to listOf(0 to 0, 1 to 0, 2 to 0, 3 to 0),
    PieceType.O to listOf(0 to 0, 1 to 0, 0 to 1, 1 to 1),
    PieceType.T to listOf(1 to 0, 0 to 1, 1 to 1, 2 to 1),
    PieceType.S to listOf(1 to 0, 2 to 0, 0 to 1, 1 to 1),
    PieceType.Z to listOf(0 to 0, 1 to 0, 1 to 1, 2 to 1),
    PieceType.J to listOf(0 to 0, 0 to 1, 1 to 1, 2 to 1),
    PieceType.L to listOf(2 to 0, 0 to 1, 1 to 1, 2 to 1),
)

fun boxSize(t: PieceType) = if (t == PieceType.I) 4 else 3

class Bag {
    private var bag = mutableListOf<PieceType>()

    fun next(): PieceType {
        if (bag.isEmpty()) {
            bag = PieceType.values().toMutableList()
            bag.shuffle()
        }
        return bag.removeAt(0)
    }
}
