package com.example.tetris.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ScoreEntry(val name: String, val score: Int)

object HighScores {
    private const val PREF = "tetris_scores"
    private const val KEY = "top"

    fun load(ctx: Context): List<ScoreEntry> {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<ScoreEntry>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(ScoreEntry(o.getString("name"), o.getInt("score")))
        }
        return list.sortedByDescending { it.score }
    }

    fun add(ctx: Context, name: String, score: Int): List<ScoreEntry> {
        val list = (load(ctx) + ScoreEntry(name, score))
            .sortedByDescending { it.score }
            .take(10)
        val arr = JSONArray()
        for (e in list) {
            arr.put(JSONObject().put("name", e.name).put("score", e.score))
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, arr.toString())
            .apply()
        return list
    }

    fun isHighScore(ctx: Context, score: Int): Boolean {
        if (score <= 0) return false
        val list = load(ctx)
        return list.size < 10 || score > list.last().score
    }
}
