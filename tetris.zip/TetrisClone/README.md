# 🎮 Tetris Android (Kotlin + Jetpack Compose)

Clon completo de Tetris: menu, niveles, puntuaciones maximas, musica,
efectos de sonido y pieza fantasma. Compilado automaticamente con GitHub Actions.

## Como compilarlo TODO DESDE EL MOVIL (sin PC)

1. Crea una cuenta en https://github.com desde el navegador del movil.
2. Crea un repositorio nuevo llamado `tetris` (marca "Add a README file").
3. En el repo: **Add file** → **Create new file** → como nombre escribe
   `.github/workflows/build.yml` → pega el contenido del archivo `build.yml`
   (esta en la carpeta github_workflow de este ZIP) → **Commit changes**.
4. De nuevo **Add file** → **Upload files** → sube el archivo `tetris.zip`
   que descargaste → **Commit changes**.
5. Ve a la pestana **Actions**: veras el proceso "Build Tetris APK".
   Espera 3-5 minutos hasta que aparezca un check verde ✅.
6. Entra en ese proceso y en la seccion **Artifacts** descarga `tetris-apk`.
   Sera otro ZIP: descomprimelo con tu gestor de archivos.
7. Toca `app-debug.apk` y acepta "Instalar apps de origenes desconocidos".
   ¡A jugar!

## Controles
- ◀ ▶ : mover
- ⟳ : girar
- ▼ : bajar rapido (+1 punto)
- ⏬ : caida instantanea (+2 puntos/casilla)
- Boton ⏸ o boton atras del movil: pausa

## Reglas
- 1/2/3/4 lineas = 40/100/300/1200 puntos x nivel
- Cada 10 lineas subes de nivel (la pieza cae mas rapido)
- Top 10 de puntuaciones guardado en el movil

## Estructura
- `game/`  - motor del juego (piezas, colisiones, lineas, niveles)
- `ui/`    - pantallas Compose (menu, juego, puntuaciones)
- `data/`  - puntuaciones maximas (SharedPreferences)
- `sound/` - musica y efectos
- `res/raw` - sonidos generados
